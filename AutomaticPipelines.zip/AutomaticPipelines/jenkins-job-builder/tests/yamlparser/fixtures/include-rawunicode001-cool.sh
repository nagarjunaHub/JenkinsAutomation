#!/bin/bash
echo "Unicode! ☃"
