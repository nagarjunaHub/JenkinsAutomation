# jjb_demo - Jenkins Job Builder

## What is this repo about?

This is a brief demo to show how to use Jenkins Job Builder

## service-jobs.yml 

Show how to trigger job updates from a job that calls jenkins job builder

## projects

projects_a and project_b shows how you can have two separate projects and jenkins 
job builder yaml to repesent them.

### project_a

Is focused on topology jjb macro to create multiple jobs

### project_b

Is focused on architecture jjb macro to create multiple jobs